Hi! Thanks for buying SimpleWeather!

You can change the addon configuration in "lua/simpleweather_config.lua" in this addon.

If you find a bug, or if something doesn't work, please make a ticket on CoderHire.

Admin commands:
sw_weather [none/rain/snow/storm/blizzard] - Change the weather.
sw_stopweather - Stop weather, if there is any.
sw_autoweather [0/1] - Turn auto-weather on and off.
sw_settime [0-24] - Set the time (0 is midnight, 12 is noon, 15 is 3pm, etc.)
sw_enabletime [0/1] - Freeze the passage of time.