local plugin = plugin;

plugin:IncludeFile( "shared.lua", SERVERGUARD.STATE.SHARED );
