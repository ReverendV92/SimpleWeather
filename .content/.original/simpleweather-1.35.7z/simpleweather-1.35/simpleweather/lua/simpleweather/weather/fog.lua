WEATHER.ID = "fog";
WEATHER.Sound = "";
WEATHER.FogStart = 0;
WEATHER.FogEnd = 1024;
WEATHER.FogMaxDensity = 0.97;
WEATHER.FogColor = Color( 255, 255, 255, 255 );